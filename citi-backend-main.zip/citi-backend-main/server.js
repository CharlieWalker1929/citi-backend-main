// Import dependencies
const express = require("express");
const bodyParser = require("body-parser");
const compression = require("compression");
const cors = require("cors");
const helmet = require("helmet");
const path = require("path");
var busboy = require("connect-busboy");
var https = require("https");
var fs = require("fs");

// Import routes
const userRoute = require("./routes/userRoute");
const depositsRoute = require("./routes/depositsRoute");
const tradesRoute = require("./routes/tradesRoute");
const productsRoutes = require("./routes/productsRoute");
const sentPaymentDetailsRoute = require("./routes/sentPaymentDetailsRoute");
const testRoute = require("./routes/testRoute");
const iposRoute = require("./routes/iposRoute");
const userSharesRoute = require("./routes/userSharesRoute");
const userSharesSalesRoute = require("./routes/userSharesSalesRoute");
const userSalesRoute = require("./routes/userSalesRoute");

// Set default port for express app
const PORT = 4100;
console.log("PORT IN SERVER: ", PORT);
//This answer is very similar to Setthase but its for LetsEncrypt (Ubuntu)

// Dependencies
// const fs = require('fs');
// const http = require('http');
// const https = require('https');
// const express = require('express');

// Create express app
const app = express();

// Certificate
// const privateKey = fs.readFileSync('/etc/letsencrypt/live/mizuhogroup.com.au/privkey.pem', 'utf8');
// const certificate = fs.readFileSync('/etc/letsencrypt/live/yourdomain.com/cert.pem', 'utf8');
// const certificate = fs.readFileSync('/etc/letsencrypt/live/mizuhogroup.com.au/fullchain.pem', 'utf8');

//const credentials = {
//    key: privateKey,
//    cert: certificate,
//};

// Apply middleware
// Note: Keep this at the top, above routes
app.use(cors());
app.use(helmet());
app.use(compression());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(busboy());
app.use(express.static("../public"));

// app.use(express.static('../build'))

// app.get('*', (req, res) => {
//    res.sendFile(path.resolve(__dirname, '../build/', 'index.html'))
// })

// Implement routes
app.use("/api/users", userRoute);
app.use("/api/deposits", depositsRoute);
app.use("/api/trades", tradesRoute);
app.use("/api/products", productsRoutes);
app.use("/api/sentPaymentDetails", sentPaymentDetailsRoute);
app.use("/api/test", testRoute);
app.use("/api/ipos", iposRoute);
app.use("/api/userShares", userSharesRoute);
app.use("/api/userSharesSales", userSharesSalesRoute);
app.use("/api/userSales", userSalesRoute);

// Uploading files route.
app.post("/api/upload", function (req, res) {
  try {
    var fstream;
    req.pipe(req.busboy);
    req.busboy.on("file", function (fieldname, file, filename) {
      console.log("Uploading: " + filename);
      var randomNumber = Math.floor(Math.random() * 10000000) + 1;
      fstream = fs.createWriteStream("../client/public/documents/" + filename);
      file.pipe(fstream);
      fstream.on("close", function () {
        res.json({ file: `/${filename}` });
      });
    });
  } catch (error) {
    console.log("Error uploading: ", error);
  }
});

// Implement 500 error route
app.use(function (err, req, res, next) {
  console.error(err.stack);
  res
    .status(500)
    .send(
      `Something is broken.  This error ${err.name}: ${err.message}. This is the stack: ${err.stack}`
    );
});

// Implement 404 error route
app.use(function (req, res, next) {
  res.status(404).send("Sorry we could not find that.");
});

// Start express app
app.listen(PORT, function () {
  console.log(`Server is running on: ${PORT}`);
});

// Start express app
// var server = https.createServer(credentials, app);

// server.listen(PORT, function () {
//  console.log(`Server is running on: ${PORT}`)
//})
